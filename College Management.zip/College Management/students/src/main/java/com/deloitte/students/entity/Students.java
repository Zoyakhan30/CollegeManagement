package com.deloitte.students.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "student")
public class Students {

	@Id
	@Column(name = "Roll_no")
	private int roll_no;
	@Column(name = "Name")
	private String name;
	@Column(name = "Course_Id")
	private String course_Id;

	public int getRoll_no() {
		return roll_no;
	}

	public void setRoll_no(int roll_no) {
		this.roll_no = roll_no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCourse_Id() {
		return course_Id;
	}

	public void setCourse_Id(String course_Id) {
		this.course_Id = course_Id;
	}

	public Students(int roll_no, String name, String course_Id) {
		super();
		this.roll_no = roll_no;
		this.name = name;
		this.course_Id = course_Id;
	}

	public Students() {
		super();
		// TODO Auto-generated constructor stub
	}

}
