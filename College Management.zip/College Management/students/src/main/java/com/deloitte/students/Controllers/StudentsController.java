package com.deloitte.students.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.students.entity.Students;
import com.deloitte.students.service.StudentServiceImpl;

@RestController
@RequestMapping("/student")
public class StudentsController {

	@Autowired
	StudentServiceImpl StudentsServiceImpl;

	@GetMapping("/getStudents")
	public ResponseEntity<List<Students>> getAllStudents() {
		List<Students> Students = StudentsServiceImpl.getStudents();
		return new ResponseEntity<List<Students>>(Students, HttpStatus.OK);
	}

}
