package com.deloitte.students.service;

import java.util.List;

import com.deloitte.students.entity.Students;

public interface StudentsService {
	public List<Students> getStudents();
		
}
