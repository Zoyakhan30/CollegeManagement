package com.deloitte.students.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.students.entity.Students;
import com.deloitte.students.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentsService {

	@Autowired
	StudentRepository StudentsRepository;

	@Override
	public List<Students> getStudents() {
		return StudentsRepository.findAll();
	}

}
