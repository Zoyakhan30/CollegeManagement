package com.deloitte.course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.course.entity.Course;
import com.deloitte.course.service.CourseServiceImpl;


@RestController
@RequestMapping("/Course")
public class CourseController {
	
	@Autowired
	CourseServiceImpl courseServiceImpl;
	@GetMapping("/getCourse")
	public ResponseEntity<List<Course>> getAllCourse(){
		List<Course> Students=courseServiceImpl.getCourse();
		return new ResponseEntity<List<Course>>(Students,HttpStatus.OK);
		}

}
