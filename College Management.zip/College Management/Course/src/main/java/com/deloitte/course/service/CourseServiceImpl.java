package com.deloitte.course.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.course.entity.Course;
import com.deloitte.course.repository.CourseRepository;


@Service
public class CourseServiceImpl implements CourseService {
	
	@Autowired
	CourseRepository CourseRepository;
	@Override
	
	public List<Course> getCourse() {
		return CourseRepository.findAll();
		}
	
	

}
