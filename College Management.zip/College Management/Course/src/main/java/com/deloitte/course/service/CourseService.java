package com.deloitte.course.service;

import java.util.List;

import com.deloitte.course.entity.Course;

public interface CourseService {
	public List<Course> getCourse();

}
